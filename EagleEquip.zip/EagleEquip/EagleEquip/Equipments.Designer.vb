﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Equipments
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Equipments))
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox5 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox8 = New PictureBox()
        btnTable = New Button()
        btnCurtain = New Button()
        btnTent = New Button()
        btnSoundSystem = New Button()
        btnProjector = New Button()
        btnProjectorScreen = New Button()
        btnMicrophone = New Button()
        btnLongTable = New Button()
        Button9 = New Button()
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        pcbRegister = New PictureBox()
        Label1 = New Label()
        PictureBox11 = New PictureBox()
        Label2 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(pcbRegister, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Location = New Point(102, 168)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(130, 119)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Location = New Point(286, 168)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(130, 119)
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Location = New Point(473, 168)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(130, 119)
        PictureBox3.TabIndex = 2
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackColor = Color.Transparent
        PictureBox4.Location = New Point(656, 168)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(130, 119)
        PictureBox4.TabIndex = 3
        PictureBox4.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BackColor = Color.Transparent
        PictureBox5.Location = New Point(656, 363)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(130, 119)
        PictureBox5.TabIndex = 7
        PictureBox5.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.Location = New Point(473, 363)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(130, 119)
        PictureBox6.TabIndex = 6
        PictureBox6.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.Location = New Point(286, 363)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(130, 119)
        PictureBox7.TabIndex = 5
        PictureBox7.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.Location = New Point(102, 363)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(130, 119)
        PictureBox8.TabIndex = 4
        PictureBox8.TabStop = False
        ' 
        ' btnTable
        ' 
        btnTable.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnTable.FlatStyle = FlatStyle.Flat
        btnTable.ForeColor = Color.White
        btnTable.Location = New Point(102, 293)
        btnTable.Name = "btnTable"
        btnTable.Size = New Size(130, 39)
        btnTable.TabIndex = 8
        btnTable.Text = "View Reserve"
        btnTable.UseVisualStyleBackColor = False
        ' 
        ' btnCurtain
        ' 
        btnCurtain.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnCurtain.FlatStyle = FlatStyle.Flat
        btnCurtain.ForeColor = Color.White
        btnCurtain.Location = New Point(286, 293)
        btnCurtain.Name = "btnCurtain"
        btnCurtain.Size = New Size(130, 39)
        btnCurtain.TabIndex = 9
        btnCurtain.Text = "View Reserve"
        btnCurtain.UseVisualStyleBackColor = False
        ' 
        ' btnTent
        ' 
        btnTent.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnTent.FlatStyle = FlatStyle.Flat
        btnTent.ForeColor = Color.White
        btnTent.Location = New Point(473, 293)
        btnTent.Name = "btnTent"
        btnTent.Size = New Size(130, 39)
        btnTent.TabIndex = 10
        btnTent.Text = "View Reserve"
        btnTent.UseVisualStyleBackColor = False
        ' 
        ' btnSoundSystem
        ' 
        btnSoundSystem.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnSoundSystem.FlatStyle = FlatStyle.Flat
        btnSoundSystem.ForeColor = Color.White
        btnSoundSystem.Location = New Point(656, 293)
        btnSoundSystem.Name = "btnSoundSystem"
        btnSoundSystem.Size = New Size(130, 39)
        btnSoundSystem.TabIndex = 11
        btnSoundSystem.Text = "View Reserve"
        btnSoundSystem.UseVisualStyleBackColor = False
        ' 
        ' btnProjector
        ' 
        btnProjector.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnProjector.FlatStyle = FlatStyle.Flat
        btnProjector.ForeColor = Color.White
        btnProjector.Location = New Point(102, 488)
        btnProjector.Name = "btnProjector"
        btnProjector.Size = New Size(130, 39)
        btnProjector.TabIndex = 12
        btnProjector.Text = "View Reserve"
        btnProjector.UseVisualStyleBackColor = False
        ' 
        ' btnProjectorScreen
        ' 
        btnProjectorScreen.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnProjectorScreen.FlatStyle = FlatStyle.Flat
        btnProjectorScreen.ForeColor = Color.White
        btnProjectorScreen.Location = New Point(286, 488)
        btnProjectorScreen.Name = "btnProjectorScreen"
        btnProjectorScreen.Size = New Size(130, 39)
        btnProjectorScreen.TabIndex = 13
        btnProjectorScreen.Text = "View Reserve"
        btnProjectorScreen.UseVisualStyleBackColor = False
        ' 
        ' btnMicrophone
        ' 
        btnMicrophone.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnMicrophone.FlatStyle = FlatStyle.Flat
        btnMicrophone.ForeColor = Color.White
        btnMicrophone.Location = New Point(473, 488)
        btnMicrophone.Name = "btnMicrophone"
        btnMicrophone.Size = New Size(130, 39)
        btnMicrophone.TabIndex = 14
        btnMicrophone.Text = "View Reserve"
        btnMicrophone.UseVisualStyleBackColor = False
        ' 
        ' btnLongTable
        ' 
        btnLongTable.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnLongTable.FlatStyle = FlatStyle.Flat
        btnLongTable.ForeColor = Color.White
        btnLongTable.Location = New Point(656, 488)
        btnLongTable.Name = "btnLongTable"
        btnLongTable.Size = New Size(130, 39)
        btnLongTable.TabIndex = 15
        btnLongTable.Text = "View Reserve"
        btnLongTable.UseVisualStyleBackColor = False
        ' 
        ' Button9
        ' 
        Button9.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Button9.FlatStyle = FlatStyle.Flat
        Button9.ForeColor = Color.White
        Button9.Location = New Point(746, 552)
        Button9.Name = "Button9"
        Button9.Size = New Size(73, 25)
        Button9.TabIndex = 16
        Button9.Text = "Logout"
        Button9.UseVisualStyleBackColor = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), Image)
        PictureBox9.Location = New Point(12, 2)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(195, 190)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 17
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), Image)
        PictureBox10.Location = New Point(157, 14)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(280, 180)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 18
        PictureBox10.TabStop = False
        ' 
        ' pcbRegister
        ' 
        pcbRegister.BackColor = Color.Transparent
        pcbRegister.Cursor = Cursors.Hand
        pcbRegister.Image = CType(resources.GetObject("pcbRegister.Image"), Image)
        pcbRegister.Location = New Point(727, 67)
        pcbRegister.Name = "pcbRegister"
        pcbRegister.Size = New Size(61, 58)
        pcbRegister.SizeMode = PictureBoxSizeMode.StretchImage
        pcbRegister.TabIndex = 19
        pcbRegister.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.ForeColor = Color.White
        Label1.Location = New Point(713, 132)
        Label1.Name = "Label1"
        Label1.Size = New Size(93, 15)
        Label1.TabIndex = 20
        Label1.Text = "Student Register"
        ' 
        ' PictureBox11
        ' 
        PictureBox11.BackColor = Color.Transparent
        PictureBox11.Cursor = Cursors.Hand
        PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), Image)
        PictureBox11.Location = New Point(627, 67)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(61, 58)
        PictureBox11.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox11.TabIndex = 21
        PictureBox11.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.ForeColor = Color.White
        Label2.Location = New Point(630, 132)
        Label2.Name = "Label2"
        Label2.Size = New Size(57, 15)
        Label2.TabIndex = 22
        Label2.Text = "Accounts"
        ' 
        ' Equipments
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(889, 632)
        Controls.Add(Label2)
        Controls.Add(PictureBox11)
        Controls.Add(Label1)
        Controls.Add(pcbRegister)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox9)
        Controls.Add(Button9)
        Controls.Add(btnLongTable)
        Controls.Add(btnMicrophone)
        Controls.Add(btnProjectorScreen)
        Controls.Add(btnProjector)
        Controls.Add(btnSoundSystem)
        Controls.Add(btnTent)
        Controls.Add(btnCurtain)
        Controls.Add(btnTable)
        Controls.Add(PictureBox5)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        DoubleBuffered = True
        FormBorderStyle = FormBorderStyle.None
        Name = "Equipments"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Equipments"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(pcbRegister, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents btnTable As Button
    Friend WithEvents btnCurtain As Button
    Friend WithEvents btnTent As Button
    Friend WithEvents btnSoundSystem As Button
    Friend WithEvents btnProjector As Button
    Friend WithEvents btnProjectorScreen As Button
    Friend WithEvents btnMicrophone As Button
    Friend WithEvents btnLongTable As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents pcbRegister As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents Label2 As Label
End Class

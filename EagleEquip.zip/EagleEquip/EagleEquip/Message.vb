﻿Public Class Message
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
        Equipments.Show()
    End Sub
End Class
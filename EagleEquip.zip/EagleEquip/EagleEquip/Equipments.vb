﻿Public Class Equipments
    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles pcbRegister.Click
        Me.Hide()
        Register.Show()
    End Sub

    Private Sub PictureBox11_Click_1(sender As Object, e As EventArgs) Handles PictureBox11.Click
        Me.Hide()
        Accounts.Show()
    End Sub
End Class
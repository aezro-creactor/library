﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EquipReserve
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EquipReserve))
        PictureBox9 = New PictureBox()
        PictureBox10 = New PictureBox()
        btnTableReserve = New Button()
        PictureBox8 = New PictureBox()
        btnCurtainReserve = New Button()
        PictureBox1 = New PictureBox()
        btnTentReserve = New Button()
        PictureBox2 = New PictureBox()
        btnSoundReserve = New Button()
        PictureBox3 = New PictureBox()
        btnLongReserve = New Button()
        PictureBox4 = New PictureBox()
        btnMicReserve = New Button()
        PictureBox5 = New PictureBox()
        btnScreenReserve = New Button()
        PictureBox6 = New PictureBox()
        btnProjectorReserve = New Button()
        PictureBox7 = New PictureBox()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox9
        ' 
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), Image)
        PictureBox9.Location = New Point(8, -3)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(195, 190)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 18
        PictureBox9.TabStop = False
        ' 
        ' PictureBox10
        ' 
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), Image)
        PictureBox10.Location = New Point(155, 12)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(280, 180)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 19
        PictureBox10.TabStop = False
        ' 
        ' btnTableReserve
        ' 
        btnTableReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnTableReserve.FlatStyle = FlatStyle.Flat
        btnTableReserve.ForeColor = Color.White
        btnTableReserve.Location = New Point(94, 289)
        btnTableReserve.Name = "btnTableReserve"
        btnTableReserve.Size = New Size(130, 39)
        btnTableReserve.TabIndex = 21
        btnTableReserve.Text = "Reserve"
        btnTableReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = Color.Transparent
        PictureBox8.Location = New Point(94, 164)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(130, 119)
        PictureBox8.TabIndex = 20
        PictureBox8.TabStop = False
        ' 
        ' btnCurtainReserve
        ' 
        btnCurtainReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnCurtainReserve.FlatStyle = FlatStyle.Flat
        btnCurtainReserve.ForeColor = Color.White
        btnCurtainReserve.Location = New Point(278, 289)
        btnCurtainReserve.Name = "btnCurtainReserve"
        btnCurtainReserve.Size = New Size(130, 39)
        btnCurtainReserve.TabIndex = 23
        btnCurtainReserve.Text = "Reserve"
        btnCurtainReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Location = New Point(278, 164)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(130, 119)
        PictureBox1.TabIndex = 22
        PictureBox1.TabStop = False
        ' 
        ' btnTentReserve
        ' 
        btnTentReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnTentReserve.FlatStyle = FlatStyle.Flat
        btnTentReserve.ForeColor = Color.White
        btnTentReserve.Location = New Point(462, 289)
        btnTentReserve.Name = "btnTentReserve"
        btnTentReserve.Size = New Size(130, 39)
        btnTentReserve.TabIndex = 25
        btnTentReserve.Text = "Reserve"
        btnTentReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Location = New Point(462, 164)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(130, 119)
        PictureBox2.TabIndex = 24
        PictureBox2.TabStop = False
        ' 
        ' btnSoundReserve
        ' 
        btnSoundReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnSoundReserve.FlatStyle = FlatStyle.Flat
        btnSoundReserve.ForeColor = Color.White
        btnSoundReserve.Location = New Point(652, 289)
        btnSoundReserve.Name = "btnSoundReserve"
        btnSoundReserve.Size = New Size(130, 39)
        btnSoundReserve.TabIndex = 27
        btnSoundReserve.Text = "Reserve"
        btnSoundReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Location = New Point(652, 164)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(130, 119)
        PictureBox3.TabIndex = 26
        PictureBox3.TabStop = False
        ' 
        ' btnLongReserve
        ' 
        btnLongReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnLongReserve.FlatStyle = FlatStyle.Flat
        btnLongReserve.ForeColor = Color.White
        btnLongReserve.Location = New Point(652, 475)
        btnLongReserve.Name = "btnLongReserve"
        btnLongReserve.Size = New Size(130, 39)
        btnLongReserve.TabIndex = 35
        btnLongReserve.Text = "Reserve"
        btnLongReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackColor = Color.Transparent
        PictureBox4.Location = New Point(652, 350)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(130, 119)
        PictureBox4.TabIndex = 34
        PictureBox4.TabStop = False
        ' 
        ' btnMicReserve
        ' 
        btnMicReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnMicReserve.FlatStyle = FlatStyle.Flat
        btnMicReserve.ForeColor = Color.White
        btnMicReserve.Location = New Point(462, 475)
        btnMicReserve.Name = "btnMicReserve"
        btnMicReserve.Size = New Size(130, 39)
        btnMicReserve.TabIndex = 33
        btnMicReserve.Text = "Reserve"
        btnMicReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BackColor = Color.Transparent
        PictureBox5.Location = New Point(462, 350)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(130, 119)
        PictureBox5.TabIndex = 32
        PictureBox5.TabStop = False
        ' 
        ' btnScreenReserve
        ' 
        btnScreenReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnScreenReserve.FlatStyle = FlatStyle.Flat
        btnScreenReserve.ForeColor = Color.White
        btnScreenReserve.Location = New Point(278, 475)
        btnScreenReserve.Name = "btnScreenReserve"
        btnScreenReserve.Size = New Size(130, 39)
        btnScreenReserve.TabIndex = 31
        btnScreenReserve.Text = "Reserve"
        btnScreenReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.Location = New Point(278, 350)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(130, 119)
        PictureBox6.TabIndex = 30
        PictureBox6.TabStop = False
        ' 
        ' btnProjectorReserve
        ' 
        btnProjectorReserve.BackColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnProjectorReserve.FlatStyle = FlatStyle.Flat
        btnProjectorReserve.ForeColor = Color.White
        btnProjectorReserve.Location = New Point(94, 475)
        btnProjectorReserve.Name = "btnProjectorReserve"
        btnProjectorReserve.Size = New Size(130, 39)
        btnProjectorReserve.TabIndex = 29
        btnProjectorReserve.Text = "Reserve"
        btnProjectorReserve.UseVisualStyleBackColor = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.Location = New Point(94, 350)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(130, 119)
        PictureBox7.TabIndex = 28
        PictureBox7.TabStop = False
        ' 
        ' EquipReserve
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), Image)
        BackgroundImageLayout = ImageLayout.Stretch
        ClientSize = New Size(873, 593)
        Controls.Add(btnLongReserve)
        Controls.Add(PictureBox4)
        Controls.Add(btnMicReserve)
        Controls.Add(PictureBox5)
        Controls.Add(btnScreenReserve)
        Controls.Add(PictureBox6)
        Controls.Add(btnProjectorReserve)
        Controls.Add(PictureBox7)
        Controls.Add(btnSoundReserve)
        Controls.Add(PictureBox3)
        Controls.Add(btnTentReserve)
        Controls.Add(PictureBox2)
        Controls.Add(btnCurtainReserve)
        Controls.Add(PictureBox1)
        Controls.Add(btnTableReserve)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox10)
        Controls.Add(PictureBox9)
        DoubleBuffered = True
        FormBorderStyle = FormBorderStyle.None
        Name = "EquipReserve"
        Text = "EquipReserve"
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents btnTableReserve As Button
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents btnCurtainReserve As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnTentReserve As Button
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnSoundReserve As Button
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnLongReserve As Button
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnMicReserve As Button
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents btnScreenReserve As Button
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents btnProjectorReserve As Button
    Friend WithEvents PictureBox7 As PictureBox
End Class

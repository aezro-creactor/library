﻿Imports MySql.Data.MySqlClient
Public Class Equipments

    Private Sub PictureBoxTable_Click(sender As Object, e As EventArgs) Handles PictureBoxTable.Click
        panelLeftSide.Height = PictureBoxTable.Height
        panelLeftSide.Top = PictureBoxTable.Top
    End Sub

    Private Sub PictureBoxChair_Click(sender As Object, e As EventArgs) Handles PictureBoxChair.Click
        panelLeftSide.Height = PictureBoxChair.Height
        panelLeftSide.Top = PictureBoxChair.Top
    End Sub

    Private Sub PictureBoxTent_Click(sender As Object, e As EventArgs) Handles PictureBoxTent.Click
        panelLeftSide.Height = PictureBoxTent.Height
        panelLeftSide.Top = PictureBoxTent.Top
    End Sub

    Private Sub PictureBoxSoundSystem_Click(sender As Object, e As EventArgs) Handles PictureBoxSoundSystem.Click
        panelLeftSide.Height = PictureBoxSoundSystem.Height
        panelLeftSide.Top = PictureBoxSoundSystem.Top
    End Sub

    Private Sub PictureBoxProjector_Click(sender As Object, e As EventArgs) Handles PictureBoxProjector.Click
        panelLeftSide.Height = PictureBoxProjector.Height
        panelLeftSide.Top = PictureBoxProjector.Top
    End Sub

    Private Sub PictureBoxScreen_Click(sender As Object, e As EventArgs) Handles PictureBoxScreen.Click
        panelLeftSide.Height = PictureBoxScreen.Height
        panelLeftSide.Top = PictureBoxScreen.Top
    End Sub

    Private Sub PictureBoxMic_Click(sender As Object, e As EventArgs) Handles PictureBoxMic.Click
        panelLeftSide.Height = PictureBoxMic.Height
        panelLeftSide.Top = PictureBoxMic.Top
    End Sub

    Private Sub PictureBoxLong_Click(sender As Object, e As EventArgs) Handles PictureBoxLong.Click
        panelLeftSide.Height = PictureBoxLong.Height
        panelLeftSide.Top = PictureBoxLong.Top
    End Sub
End Class
﻿Public Class Admin_Login
    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles pcbShow.Click
        ' Show the password
        txtPassword.PasswordChar = Nothing

        ' Swap visibility of the PictureBox controls
        pcbShow.Visible = False
        pcbHide.Visible = True
    End Sub

    Private Sub pcbHide_Click(sender As Object, e As EventArgs) Handles pcbHide.Click
        ' Hide the password
        txtPassword.PasswordChar = "*"

        ' Swap visibility of the PictureBox controls
        pcbShow.Visible = True
        pcbHide.Visible = False
    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "admin" And txtPassword.Text = "00000" Then
            Admin_Interface.Show()
        Else
            MessageBox.Show("Invalid Credentials.")
        End If
    End Sub
End Class
﻿Public Class Admin_Interface

    Sub switchPanel(ByVal panel As Form)
        MainPanel.Controls.Clear()
        panel.TopLevel = False
        MainPanel.Controls.Add(panel)
        panel.Show()
    End Sub
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles btnTable.Click
        panelLeftSide.Height = btnTable.Height
        panelLeftSide.Top = btnTable.Top
        pnlTable.Visible = True
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnChair_Click(sender As Object, e As EventArgs) Handles btnChair.Click
        panelLeftSide.Height = btnChair.Height
        panelLeftSide.Top = btnChair.Top
        pnlTable.Visible = False
        pnlChair.Visible = True
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnTent_Click(sender As Object, e As EventArgs) Handles btnTent.Click
        panelLeftSide.Height = btnTent.Height
        panelLeftSide.Top = btnTent.Top
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = True
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnSoundSystem_Click(sender As Object, e As EventArgs) Handles btnSoundSystem.Click
        panelLeftSide.Height = btnSoundSystem.Height
        panelLeftSide.Top = btnSoundSystem.Top
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = True
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnProjector_Click(sender As Object, e As EventArgs) Handles btnProjector.Click
        panelLeftSide.Height = btnProjector.Height
        panelLeftSide.Top = btnProjector.Top
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = True
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnScreenProjector_Click(sender As Object, e As EventArgs) Handles btnScreenProjector.Click
        panelLeftSide.Height = btnScreenProjector.Height
        panelLeftSide.Top = btnScreenProjector.Top
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = True
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnMicrophone_Click(sender As Object, e As EventArgs) Handles btnMicrophone.Click
        panelLeftSide.Height = btnMicrophone.Height
        panelLeftSide.Top = btnMicrophone.Top
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = True
        pnlLongTable.Visible = False
        MainPanel.Visible = False
    End Sub

    Private Sub btnLongTable_Click(sender As Object, e As EventArgs) Handles btnLongTable.Click
        panelLeftSide.Height = btnLongTable.Height
        panelLeftSide.Top = btnLongTable.Top
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = True
        MainPanel.Visible = False
    End Sub

    Private Sub MainPanel_Paint(sender As Object, e As PaintEventArgs) Handles MainPanel.Paint

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        switchPanel(SignUp)
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = True
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles PictureBox11.Click
        switchPanel(Accounts)
        pnlTable.Visible = False
        pnlChair.Visible = False
        pnlTent.Visible = False
        pnlSoundSystem.Visible = False
        pnlProjector.Visible = False
        pnlScreenProjector.Visible = False
        pnlMicrophone.Visible = False
        pnlLongTable.Visible = False
        MainPanel.Visible = True
    End Sub
End Class
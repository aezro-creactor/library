﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SignUp
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SignUp))
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        Label3 = New Label()
        txtName = New TextBox()
        txtClub = New TextBox()
        txtUsername = New TextBox()
        txtPosition = New TextBox()
        txtConfirmPassword = New TextBox()
        txtPassword = New TextBox()
        btnSubmit = New Button()
        Label1 = New Label()
        Label2 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(204, 12)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(224, 177)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 6
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(60, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(183, 177)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 5
        PictureBox1.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI Black", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label3.Location = New Point(109, 158)
        Label3.Name = "Label3"
        Label3.Size = New Size(92, 30)
        Label3.TabIndex = 15
        Label3.Text = "Sign Up"
        ' 
        ' txtName
        ' 
        txtName.BorderStyle = BorderStyle.None
        txtName.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtName.Location = New Point(109, 240)
        txtName.Name = "txtName"
        txtName.Size = New Size(187, 36)
        txtName.TabIndex = 16
        ' 
        ' txtClub
        ' 
        txtClub.BorderStyle = BorderStyle.None
        txtClub.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtClub.Location = New Point(362, 240)
        txtClub.Name = "txtClub"
        txtClub.Size = New Size(187, 36)
        txtClub.TabIndex = 17
        ' 
        ' txtUsername
        ' 
        txtUsername.BorderStyle = BorderStyle.None
        txtUsername.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtUsername.Location = New Point(362, 314)
        txtUsername.Name = "txtUsername"
        txtUsername.Size = New Size(187, 36)
        txtUsername.TabIndex = 19
        ' 
        ' txtPosition
        ' 
        txtPosition.BorderStyle = BorderStyle.None
        txtPosition.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPosition.Location = New Point(109, 314)
        txtPosition.Name = "txtPosition"
        txtPosition.Size = New Size(187, 36)
        txtPosition.TabIndex = 18
        ' 
        ' txtConfirmPassword
        ' 
        txtConfirmPassword.BorderStyle = BorderStyle.None
        txtConfirmPassword.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtConfirmPassword.Location = New Point(362, 389)
        txtConfirmPassword.Name = "txtConfirmPassword"
        txtConfirmPassword.Size = New Size(187, 36)
        txtConfirmPassword.TabIndex = 21
        txtConfirmPassword.UseSystemPasswordChar = True
        ' 
        ' txtPassword
        ' 
        txtPassword.BorderStyle = BorderStyle.None
        txtPassword.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPassword.Location = New Point(109, 389)
        txtPassword.Name = "txtPassword"
        txtPassword.Size = New Size(187, 36)
        txtPassword.TabIndex = 20
        txtPassword.UseSystemPasswordChar = True
        ' 
        ' btnSubmit
        ' 
        btnSubmit.FlatStyle = FlatStyle.Flat
        btnSubmit.Font = New Font("Segoe UI Black", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSubmit.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnSubmit.Location = New Point(241, 447)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(187, 36)
        btnSubmit.TabIndex = 22
        btnSubmit.Text = "Submit"
        btnSubmit.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label1.Location = New Point(362, 290)
        Label1.Name = "Label1"
        Label1.Size = New Size(87, 21)
        Label1.TabIndex = 23
        Label1.Text = "Username"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label2.Location = New Point(362, 365)
        Label2.Name = "Label2"
        Label2.Size = New Size(148, 21)
        Label2.TabIndex = 24
        Label2.Text = "Confirm Password"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label4.Location = New Point(109, 365)
        Label4.Name = "Label4"
        Label4.Size = New Size(82, 21)
        Label4.TabIndex = 25
        Label4.Text = "Password"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label5.Location = New Point(362, 216)
        Label5.Name = "Label5"
        Label5.Size = New Size(45, 21)
        Label5.TabIndex = 26
        Label5.Text = "Club"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label6.Location = New Point(109, 290)
        Label6.Name = "Label6"
        Label6.Size = New Size(73, 21)
        Label6.TabIndex = 27
        Label6.Text = "Position"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label7.Location = New Point(109, 216)
        Label7.Name = "Label7"
        Label7.Size = New Size(56, 21)
        Label7.TabIndex = 28
        Label7.Text = "Name"
        ' 
        ' SignUp
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Control
        ClientSize = New Size(651, 532)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnSubmit)
        Controls.Add(txtConfirmPassword)
        Controls.Add(txtPassword)
        Controls.Add(txtUsername)
        Controls.Add(txtPosition)
        Controls.Add(txtClub)
        Controls.Add(txtName)
        Controls.Add(Label3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        FormBorderStyle = FormBorderStyle.None
        Name = "SignUp"
        Text = "SignUp"
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtName As TextBox
    Friend WithEvents txtClub As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents txtConfirmPassword As TextBox
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
End Class

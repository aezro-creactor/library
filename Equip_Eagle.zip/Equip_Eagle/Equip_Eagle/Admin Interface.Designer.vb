﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin_Interface
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Admin_Interface))
        Panel1 = New Panel()
        panelLeftSide = New Panel()
        btnLongTable = New Button()
        btnMicrophone = New Button()
        btnScreenProjector = New Button()
        btnProjector = New Button()
        btnSoundSystem = New Button()
        btnTent = New Button()
        btnChair = New Button()
        btnTable = New Button()
        Panel2 = New Panel()
        Label10 = New Label()
        PictureBox11 = New PictureBox()
        Label1 = New Label()
        pnlTable = New Panel()
        Label2 = New Label()
        PictureBox1 = New PictureBox()
        DataGridViewTable = New DataGridView()
        pnlChair = New Panel()
        Label3 = New Label()
        PictureBox2 = New PictureBox()
        DataGridViewChair = New DataGridView()
        pnlTent = New Panel()
        Label4 = New Label()
        PictureBox3 = New PictureBox()
        DataGridViewTent = New DataGridView()
        pnlSoundSystem = New Panel()
        Label5 = New Label()
        PictureBox4 = New PictureBox()
        DataGridViewSoundSystem = New DataGridView()
        pnlProjector = New Panel()
        Label6 = New Label()
        PictureBox5 = New PictureBox()
        DataGridViewProjector = New DataGridView()
        pnlLongTable = New Panel()
        Label9 = New Label()
        PictureBox8 = New PictureBox()
        DataGridViewLongTable = New DataGridView()
        pnlScreenProjector = New Panel()
        Label7 = New Label()
        PictureBox6 = New PictureBox()
        DataGridViewScreenProjector = New DataGridView()
        pnlMicrophone = New Panel()
        Label8 = New Label()
        PictureBox7 = New PictureBox()
        DataGridViewMicrophone = New DataGridView()
        MainPanel = New Panel()
        PictureBox10 = New PictureBox()
        PictureBox9 = New PictureBox()
        Panel1.SuspendLayout()
        Panel2.SuspendLayout()
        CType(PictureBox11, ComponentModel.ISupportInitialize).BeginInit()
        pnlTable.SuspendLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewTable, ComponentModel.ISupportInitialize).BeginInit()
        pnlChair.SuspendLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewChair, ComponentModel.ISupportInitialize).BeginInit()
        pnlTent.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewTent, ComponentModel.ISupportInitialize).BeginInit()
        pnlSoundSystem.SuspendLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewSoundSystem, ComponentModel.ISupportInitialize).BeginInit()
        pnlProjector.SuspendLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewProjector, ComponentModel.ISupportInitialize).BeginInit()
        pnlLongTable.SuspendLayout()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewLongTable, ComponentModel.ISupportInitialize).BeginInit()
        pnlScreenProjector.SuspendLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewScreenProjector, ComponentModel.ISupportInitialize).BeginInit()
        pnlMicrophone.SuspendLayout()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(DataGridViewMicrophone, ComponentModel.ISupportInitialize).BeginInit()
        MainPanel.SuspendLayout()
        CType(PictureBox10, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(3), CByte(140), CByte(233))
        Panel1.Controls.Add(panelLeftSide)
        Panel1.Controls.Add(btnLongTable)
        Panel1.Controls.Add(btnMicrophone)
        Panel1.Controls.Add(btnScreenProjector)
        Panel1.Controls.Add(btnProjector)
        Panel1.Controls.Add(btnSoundSystem)
        Panel1.Controls.Add(btnTent)
        Panel1.Controls.Add(btnChair)
        Panel1.Controls.Add(btnTable)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(200, 582)
        Panel1.TabIndex = 0
        ' 
        ' panelLeftSide
        ' 
        panelLeftSide.BackColor = Color.FromArgb(CByte(82), CByte(113), CByte(255))
        panelLeftSide.Location = New Point(0, 132)
        panelLeftSide.Name = "panelLeftSide"
        panelLeftSide.Size = New Size(12, 46)
        panelLeftSide.TabIndex = 8
        ' 
        ' btnLongTable
        ' 
        btnLongTable.FlatAppearance.BorderSize = 0
        btnLongTable.FlatStyle = FlatStyle.Flat
        btnLongTable.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnLongTable.ForeColor = Color.White
        btnLongTable.ImageAlign = ContentAlignment.MiddleLeft
        btnLongTable.Location = New Point(1, 494)
        btnLongTable.Name = "btnLongTable"
        btnLongTable.Size = New Size(198, 46)
        btnLongTable.TabIndex = 15
        btnLongTable.Text = "Long Table"
        btnLongTable.UseVisualStyleBackColor = True
        ' 
        ' btnMicrophone
        ' 
        btnMicrophone.FlatAppearance.BorderSize = 0
        btnMicrophone.FlatStyle = FlatStyle.Flat
        btnMicrophone.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnMicrophone.ForeColor = Color.White
        btnMicrophone.ImageAlign = ContentAlignment.MiddleLeft
        btnMicrophone.Location = New Point(1, 442)
        btnMicrophone.Name = "btnMicrophone"
        btnMicrophone.Size = New Size(198, 46)
        btnMicrophone.TabIndex = 14
        btnMicrophone.Text = "Microphone"
        btnMicrophone.UseVisualStyleBackColor = True
        ' 
        ' btnScreenProjector
        ' 
        btnScreenProjector.FlatAppearance.BorderSize = 0
        btnScreenProjector.FlatStyle = FlatStyle.Flat
        btnScreenProjector.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnScreenProjector.ForeColor = Color.White
        btnScreenProjector.ImageAlign = ContentAlignment.MiddleLeft
        btnScreenProjector.Location = New Point(1, 390)
        btnScreenProjector.Name = "btnScreenProjector"
        btnScreenProjector.Size = New Size(198, 46)
        btnScreenProjector.TabIndex = 13
        btnScreenProjector.Text = "Screen Projector"
        btnScreenProjector.UseVisualStyleBackColor = True
        ' 
        ' btnProjector
        ' 
        btnProjector.FlatAppearance.BorderSize = 0
        btnProjector.FlatStyle = FlatStyle.Flat
        btnProjector.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnProjector.ForeColor = Color.White
        btnProjector.ImageAlign = ContentAlignment.MiddleLeft
        btnProjector.Location = New Point(1, 338)
        btnProjector.Name = "btnProjector"
        btnProjector.Size = New Size(198, 46)
        btnProjector.TabIndex = 12
        btnProjector.Text = "Projector"
        btnProjector.UseVisualStyleBackColor = True
        ' 
        ' btnSoundSystem
        ' 
        btnSoundSystem.FlatAppearance.BorderSize = 0
        btnSoundSystem.FlatStyle = FlatStyle.Flat
        btnSoundSystem.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSoundSystem.ForeColor = Color.White
        btnSoundSystem.ImageAlign = ContentAlignment.MiddleLeft
        btnSoundSystem.Location = New Point(1, 286)
        btnSoundSystem.Name = "btnSoundSystem"
        btnSoundSystem.Size = New Size(198, 46)
        btnSoundSystem.TabIndex = 11
        btnSoundSystem.Text = "Sound System"
        btnSoundSystem.UseVisualStyleBackColor = True
        ' 
        ' btnTent
        ' 
        btnTent.FlatAppearance.BorderSize = 0
        btnTent.FlatStyle = FlatStyle.Flat
        btnTent.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnTent.ForeColor = Color.White
        btnTent.ImageAlign = ContentAlignment.MiddleLeft
        btnTent.Location = New Point(0, 234)
        btnTent.Name = "btnTent"
        btnTent.Size = New Size(198, 46)
        btnTent.TabIndex = 10
        btnTent.Text = "Tent"
        btnTent.UseVisualStyleBackColor = True
        ' 
        ' btnChair
        ' 
        btnChair.FlatAppearance.BorderSize = 0
        btnChair.FlatStyle = FlatStyle.Flat
        btnChair.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnChair.ForeColor = Color.White
        btnChair.ImageAlign = ContentAlignment.MiddleLeft
        btnChair.Location = New Point(1, 182)
        btnChair.Name = "btnChair"
        btnChair.Size = New Size(198, 46)
        btnChair.TabIndex = 9
        btnChair.Text = "Chair"
        btnChair.UseVisualStyleBackColor = True
        ' 
        ' btnTable
        ' 
        btnTable.FlatAppearance.BorderSize = 0
        btnTable.FlatStyle = FlatStyle.Flat
        btnTable.Font = New Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnTable.ForeColor = Color.White
        btnTable.ImageAlign = ContentAlignment.MiddleLeft
        btnTable.Location = New Point(2, 132)
        btnTable.Name = "btnTable"
        btnTable.Size = New Size(198, 46)
        btnTable.TabIndex = 0
        btnTable.Text = "Table"
        btnTable.UseVisualStyleBackColor = True
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(82), CByte(113), CByte(255))
        Panel2.Controls.Add(Label10)
        Panel2.Controls.Add(PictureBox11)
        Panel2.Controls.Add(Label1)
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(200, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(651, 50)
        Panel2.TabIndex = 1
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label10.ForeColor = Color.White
        Label10.Location = New Point(56, 22)
        Label10.Name = "Label10"
        Label10.Size = New Size(78, 21)
        Label10.TabIndex = 2
        Label10.Text = "Accounts"
        ' 
        ' PictureBox11
        ' 
        PictureBox11.Cursor = Cursors.Hand
        PictureBox11.Image = CType(resources.GetObject("PictureBox11.Image"), Image)
        PictureBox11.Location = New Point(6, 5)
        PictureBox11.Name = "PictureBox11"
        PictureBox11.Size = New Size(48, 40)
        PictureBox11.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox11.TabIndex = 1
        PictureBox11.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Cursor = Cursors.Hand
        Label1.Font = New Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = Color.White
        Label1.Location = New Point(525, 22)
        Label1.Name = "Label1"
        Label1.Size = New Size(123, 21)
        Label1.TabIndex = 0
        Label1.Text = "Create Account"
        ' 
        ' pnlTable
        ' 
        pnlTable.Controls.Add(Label2)
        pnlTable.Controls.Add(PictureBox1)
        pnlTable.Controls.Add(DataGridViewTable)
        pnlTable.Dock = DockStyle.Fill
        pnlTable.Location = New Point(200, 50)
        pnlTable.Name = "pnlTable"
        pnlTable.Size = New Size(651, 532)
        pnlTable.TabIndex = 2
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label2.Location = New Point(77, 229)
        Label2.Name = "Label2"
        Label2.Size = New Size(74, 32)
        Label2.TabIndex = 2
        Label2.Text = "Table"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Location = New Point(20, 23)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(192, 190)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' DataGridViewTable
        ' 
        DataGridViewTable.BackgroundColor = Color.White
        DataGridViewTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewTable.GridColor = Color.Black
        DataGridViewTable.Location = New Point(243, 28)
        DataGridViewTable.Name = "DataGridViewTable"
        DataGridViewTable.Size = New Size(396, 473)
        DataGridViewTable.TabIndex = 0
        ' 
        ' pnlChair
        ' 
        pnlChair.Controls.Add(Label3)
        pnlChair.Controls.Add(PictureBox2)
        pnlChair.Controls.Add(DataGridViewChair)
        pnlChair.Dock = DockStyle.Fill
        pnlChair.Location = New Point(200, 50)
        pnlChair.Name = "pnlChair"
        pnlChair.Size = New Size(651, 532)
        pnlChair.TabIndex = 3
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label3.Location = New Point(78, 229)
        Label3.Name = "Label3"
        Label3.Size = New Size(73, 32)
        Label3.TabIndex = 2
        Label3.Text = "Chair"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Location = New Point(20, 23)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(192, 190)
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' DataGridViewChair
        ' 
        DataGridViewChair.BackgroundColor = Color.White
        DataGridViewChair.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewChair.GridColor = Color.Black
        DataGridViewChair.Location = New Point(243, 28)
        DataGridViewChair.Name = "DataGridViewChair"
        DataGridViewChair.Size = New Size(396, 473)
        DataGridViewChair.TabIndex = 0
        ' 
        ' pnlTent
        ' 
        pnlTent.Controls.Add(Label4)
        pnlTent.Controls.Add(PictureBox3)
        pnlTent.Controls.Add(DataGridViewTent)
        pnlTent.Dock = DockStyle.Fill
        pnlTent.Location = New Point(200, 50)
        pnlTent.Name = "pnlTent"
        pnlTent.Size = New Size(651, 532)
        pnlTent.TabIndex = 3
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label4.Location = New Point(78, 229)
        Label4.Name = "Label4"
        Label4.Size = New Size(63, 32)
        Label4.TabIndex = 2
        Label4.Text = "Tent"
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Location = New Point(20, 23)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(192, 190)
        PictureBox3.TabIndex = 1
        PictureBox3.TabStop = False
        ' 
        ' DataGridViewTent
        ' 
        DataGridViewTent.BackgroundColor = Color.White
        DataGridViewTent.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewTent.GridColor = Color.Black
        DataGridViewTent.Location = New Point(243, 28)
        DataGridViewTent.Name = "DataGridViewTent"
        DataGridViewTent.Size = New Size(396, 473)
        DataGridViewTent.TabIndex = 0
        ' 
        ' pnlSoundSystem
        ' 
        pnlSoundSystem.Controls.Add(Label5)
        pnlSoundSystem.Controls.Add(PictureBox4)
        pnlSoundSystem.Controls.Add(DataGridViewSoundSystem)
        pnlSoundSystem.Dock = DockStyle.Fill
        pnlSoundSystem.Location = New Point(200, 50)
        pnlSoundSystem.Name = "pnlSoundSystem"
        pnlSoundSystem.Size = New Size(651, 532)
        pnlSoundSystem.TabIndex = 4
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label5.Location = New Point(30, 230)
        Label5.Name = "Label5"
        Label5.Size = New Size(174, 32)
        Label5.TabIndex = 2
        Label5.Text = "Sound System"
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Location = New Point(20, 23)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(192, 190)
        PictureBox4.TabIndex = 1
        PictureBox4.TabStop = False
        ' 
        ' DataGridViewSoundSystem
        ' 
        DataGridViewSoundSystem.BackgroundColor = Color.White
        DataGridViewSoundSystem.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewSoundSystem.GridColor = Color.Black
        DataGridViewSoundSystem.Location = New Point(243, 28)
        DataGridViewSoundSystem.Name = "DataGridViewSoundSystem"
        DataGridViewSoundSystem.Size = New Size(396, 473)
        DataGridViewSoundSystem.TabIndex = 0
        ' 
        ' pnlProjector
        ' 
        pnlProjector.Controls.Add(Label6)
        pnlProjector.Controls.Add(PictureBox5)
        pnlProjector.Controls.Add(DataGridViewProjector)
        pnlProjector.Dock = DockStyle.Fill
        pnlProjector.Location = New Point(200, 50)
        pnlProjector.Name = "pnlProjector"
        pnlProjector.Size = New Size(651, 532)
        pnlProjector.TabIndex = 5
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label6.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label6.Location = New Point(51, 229)
        Label6.Name = "Label6"
        Label6.Size = New Size(120, 32)
        Label6.TabIndex = 2
        Label6.Text = "Projector"
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Location = New Point(20, 23)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(192, 190)
        PictureBox5.TabIndex = 1
        PictureBox5.TabStop = False
        ' 
        ' DataGridViewProjector
        ' 
        DataGridViewProjector.BackgroundColor = Color.White
        DataGridViewProjector.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewProjector.GridColor = Color.Black
        DataGridViewProjector.Location = New Point(243, 28)
        DataGridViewProjector.Name = "DataGridViewProjector"
        DataGridViewProjector.Size = New Size(396, 473)
        DataGridViewProjector.TabIndex = 0
        ' 
        ' pnlLongTable
        ' 
        pnlLongTable.Controls.Add(Label9)
        pnlLongTable.Controls.Add(PictureBox8)
        pnlLongTable.Controls.Add(DataGridViewLongTable)
        pnlLongTable.Dock = DockStyle.Fill
        pnlLongTable.Location = New Point(200, 50)
        pnlLongTable.Name = "pnlLongTable"
        pnlLongTable.Size = New Size(651, 532)
        pnlLongTable.TabIndex = 3
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label9.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label9.Location = New Point(46, 231)
        Label9.Name = "Label9"
        Label9.Size = New Size(138, 32)
        Label9.TabIndex = 2
        Label9.Text = "Long Table"
        ' 
        ' PictureBox8
        ' 
        PictureBox8.Location = New Point(20, 23)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(192, 190)
        PictureBox8.TabIndex = 1
        PictureBox8.TabStop = False
        ' 
        ' DataGridViewLongTable
        ' 
        DataGridViewLongTable.BackgroundColor = Color.White
        DataGridViewLongTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewLongTable.GridColor = Color.Black
        DataGridViewLongTable.Location = New Point(243, 28)
        DataGridViewLongTable.Name = "DataGridViewLongTable"
        DataGridViewLongTable.Size = New Size(396, 473)
        DataGridViewLongTable.TabIndex = 0
        ' 
        ' pnlScreenProjector
        ' 
        pnlScreenProjector.Controls.Add(Label7)
        pnlScreenProjector.Controls.Add(PictureBox6)
        pnlScreenProjector.Controls.Add(DataGridViewScreenProjector)
        pnlScreenProjector.Dock = DockStyle.Fill
        pnlScreenProjector.Location = New Point(200, 50)
        pnlScreenProjector.Name = "pnlScreenProjector"
        pnlScreenProjector.Size = New Size(651, 532)
        pnlScreenProjector.TabIndex = 3
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label7.Location = New Point(14, 229)
        Label7.Name = "Label7"
        Label7.Size = New Size(203, 32)
        Label7.TabIndex = 2
        Label7.Text = "Screen Projector"
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Location = New Point(20, 23)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(192, 190)
        PictureBox6.TabIndex = 1
        PictureBox6.TabStop = False
        ' 
        ' DataGridViewScreenProjector
        ' 
        DataGridViewScreenProjector.BackgroundColor = Color.White
        DataGridViewScreenProjector.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewScreenProjector.GridColor = Color.Black
        DataGridViewScreenProjector.Location = New Point(243, 28)
        DataGridViewScreenProjector.Name = "DataGridViewScreenProjector"
        DataGridViewScreenProjector.Size = New Size(396, 473)
        DataGridViewScreenProjector.TabIndex = 0
        ' 
        ' pnlMicrophone
        ' 
        pnlMicrophone.Controls.Add(Label8)
        pnlMicrophone.Controls.Add(PictureBox7)
        pnlMicrophone.Controls.Add(DataGridViewMicrophone)
        pnlMicrophone.Dock = DockStyle.Fill
        pnlMicrophone.Location = New Point(200, 50)
        pnlMicrophone.Name = "pnlMicrophone"
        pnlMicrophone.Size = New Size(651, 532)
        pnlMicrophone.TabIndex = 3
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label8.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label8.Location = New Point(39, 227)
        Label8.Name = "Label8"
        Label8.Size = New Size(153, 32)
        Label8.TabIndex = 2
        Label8.Text = "Microphone"
        ' 
        ' PictureBox7
        ' 
        PictureBox7.Location = New Point(20, 23)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(192, 190)
        PictureBox7.TabIndex = 1
        PictureBox7.TabStop = False
        ' 
        ' DataGridViewMicrophone
        ' 
        DataGridViewMicrophone.BackgroundColor = Color.White
        DataGridViewMicrophone.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewMicrophone.GridColor = Color.Black
        DataGridViewMicrophone.Location = New Point(243, 28)
        DataGridViewMicrophone.Name = "DataGridViewMicrophone"
        DataGridViewMicrophone.Size = New Size(396, 473)
        DataGridViewMicrophone.TabIndex = 0
        ' 
        ' MainPanel
        ' 
        MainPanel.Controls.Add(PictureBox10)
        MainPanel.Controls.Add(PictureBox9)
        MainPanel.Dock = DockStyle.Fill
        MainPanel.Location = New Point(200, 50)
        MainPanel.Name = "MainPanel"
        MainPanel.Size = New Size(651, 532)
        MainPanel.TabIndex = 3
        ' 
        ' PictureBox10
        ' 
        PictureBox10.BackColor = Color.Transparent
        PictureBox10.Image = CType(resources.GetObject("PictureBox10.Image"), Image)
        PictureBox10.Location = New Point(180, 0)
        PictureBox10.Name = "PictureBox10"
        PictureBox10.Size = New Size(351, 213)
        PictureBox10.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox10.TabIndex = 1
        PictureBox10.TabStop = False
        ' 
        ' PictureBox9
        ' 
        PictureBox9.BackColor = Color.Transparent
        PictureBox9.Image = CType(resources.GetObject("PictureBox9.Image"), Image)
        PictureBox9.Location = New Point(0, 0)
        PictureBox9.Name = "PictureBox9"
        PictureBox9.Size = New Size(239, 213)
        PictureBox9.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox9.TabIndex = 0
        PictureBox9.TabStop = False
        ' 
        ' Admin_Interface
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(851, 582)
        Controls.Add(MainPanel)
        Controls.Add(pnlTable)
        Controls.Add(pnlChair)
        Controls.Add(pnlTent)
        Controls.Add(pnlSoundSystem)
        Controls.Add(pnlProjector)
        Controls.Add(pnlScreenProjector)
        Controls.Add(pnlMicrophone)
        Controls.Add(pnlLongTable)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        ForeColor = SystemColors.ControlDark
        FormBorderStyle = FormBorderStyle.None
        Name = "Admin_Interface"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Admin_Interface"
        Panel1.ResumeLayout(False)
        Panel2.ResumeLayout(False)
        Panel2.PerformLayout()
        CType(PictureBox11, ComponentModel.ISupportInitialize).EndInit()
        pnlTable.ResumeLayout(False)
        pnlTable.PerformLayout()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewTable, ComponentModel.ISupportInitialize).EndInit()
        pnlChair.ResumeLayout(False)
        pnlChair.PerformLayout()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewChair, ComponentModel.ISupportInitialize).EndInit()
        pnlTent.ResumeLayout(False)
        pnlTent.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewTent, ComponentModel.ISupportInitialize).EndInit()
        pnlSoundSystem.ResumeLayout(False)
        pnlSoundSystem.PerformLayout()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewSoundSystem, ComponentModel.ISupportInitialize).EndInit()
        pnlProjector.ResumeLayout(False)
        pnlProjector.PerformLayout()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewProjector, ComponentModel.ISupportInitialize).EndInit()
        pnlLongTable.ResumeLayout(False)
        pnlLongTable.PerformLayout()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewLongTable, ComponentModel.ISupportInitialize).EndInit()
        pnlScreenProjector.ResumeLayout(False)
        pnlScreenProjector.PerformLayout()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewScreenProjector, ComponentModel.ISupportInitialize).EndInit()
        pnlMicrophone.ResumeLayout(False)
        pnlMicrophone.PerformLayout()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(DataGridViewMicrophone, ComponentModel.ISupportInitialize).EndInit()
        MainPanel.ResumeLayout(False)
        CType(PictureBox10, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox9, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents btnTable As Button
    Friend WithEvents btnChair As Button
    Friend WithEvents panelLeftSide As Panel
    Friend WithEvents btnLongTable As Button
    Friend WithEvents btnMicrophone As Button
    Friend WithEvents btnScreenProjector As Button
    Friend WithEvents btnProjector As Button
    Friend WithEvents btnSoundSystem As Button
    Friend WithEvents btnTent As Button
    Friend WithEvents pnlTable As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents DataGridViewTable As DataGridView
    Friend WithEvents pnlChair As Panel
    Friend WithEvents Label3 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents DataGridViewChair As DataGridView
    Friend WithEvents pnlTent As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents DataGridViewTent As DataGridView
    Friend WithEvents pnlSoundSystem As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents DataGridViewSoundSystem As DataGridView
    Friend WithEvents pnlProjector As Panel
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents DataGridViewProjector As DataGridView
    Friend WithEvents pnlLongTable As Panel
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents DataGridViewLongTable As DataGridView
    Friend WithEvents Label9 As Label
    Friend WithEvents pnlScreenProjector As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents DataGridViewScreenProjector As DataGridView
    Friend WithEvents pnlMicrophone As Panel
    Friend WithEvents Label8 As Label
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents DataGridViewMicrophone As DataGridView
    Friend WithEvents MainPanel As Panel
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents Label10 As Label
End Class

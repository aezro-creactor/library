﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Equipments
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Equipments))
        Panel1 = New Panel()
        PictureBoxLong = New PictureBox()
        PictureBoxMic = New PictureBox()
        PictureBoxScreen = New PictureBox()
        PictureBoxProjector = New PictureBox()
        PictureBoxSoundSystem = New PictureBox()
        PictureBoxTent = New PictureBox()
        PictureBoxChair = New PictureBox()
        panelLeftSide = New Panel()
        PictureBoxTable = New PictureBox()
        Panel2 = New Panel()
        pnlTable = New Panel()
        lblAvailability = New Label()
        btnSubmit = New Button()
        Panel4 = New Panel()
        DateTimePickerReturn = New DateTimePicker()
        DateTimePickerBorrow = New DateTimePicker()
        Label5 = New Label()
        txtPurpose = New TextBox()
        PictureBox3 = New PictureBox()
        PictureBox2 = New PictureBox()
        TextBox1 = New TextBox()
        Label7 = New Label()
        Label4 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        txtName = New TextBox()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Panel1.SuspendLayout()
        CType(PictureBoxLong, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxMic, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxScreen, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxProjector, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxSoundSystem, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxTent, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxChair, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBoxTable, ComponentModel.ISupportInitialize).BeginInit()
        pnlTable.SuspendLayout()
        Panel4.SuspendLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Panel1
        ' 
        Panel1.BackColor = Color.FromArgb(CByte(3), CByte(140), CByte(233))
        Panel1.Controls.Add(PictureBoxLong)
        Panel1.Controls.Add(PictureBoxMic)
        Panel1.Controls.Add(PictureBoxScreen)
        Panel1.Controls.Add(PictureBoxProjector)
        Panel1.Controls.Add(PictureBoxSoundSystem)
        Panel1.Controls.Add(PictureBoxTent)
        Panel1.Controls.Add(PictureBoxChair)
        Panel1.Controls.Add(panelLeftSide)
        Panel1.Controls.Add(PictureBoxTable)
        Panel1.Dock = DockStyle.Left
        Panel1.Location = New Point(0, 0)
        Panel1.Name = "Panel1"
        Panel1.Size = New Size(104, 543)
        Panel1.TabIndex = 0
        ' 
        ' PictureBoxLong
        ' 
        PictureBoxLong.Cursor = Cursors.Hand
        PictureBoxLong.Image = CType(resources.GetObject("PictureBoxLong.Image"), Image)
        PictureBoxLong.Location = New Point(28, 441)
        PictureBoxLong.Name = "PictureBoxLong"
        PictureBoxLong.Size = New Size(41, 36)
        PictureBoxLong.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxLong.TabIndex = 8
        PictureBoxLong.TabStop = False
        ' 
        ' PictureBoxMic
        ' 
        PictureBoxMic.Cursor = Cursors.Hand
        PictureBoxMic.Image = CType(resources.GetObject("PictureBoxMic.Image"), Image)
        PictureBoxMic.Location = New Point(28, 389)
        PictureBoxMic.Name = "PictureBoxMic"
        PictureBoxMic.Size = New Size(41, 36)
        PictureBoxMic.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxMic.TabIndex = 7
        PictureBoxMic.TabStop = False
        ' 
        ' PictureBoxScreen
        ' 
        PictureBoxScreen.Cursor = Cursors.Hand
        PictureBoxScreen.Image = CType(resources.GetObject("PictureBoxScreen.Image"), Image)
        PictureBoxScreen.Location = New Point(28, 335)
        PictureBoxScreen.Name = "PictureBoxScreen"
        PictureBoxScreen.Size = New Size(41, 36)
        PictureBoxScreen.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxScreen.TabIndex = 6
        PictureBoxScreen.TabStop = False
        ' 
        ' PictureBoxProjector
        ' 
        PictureBoxProjector.Cursor = Cursors.Hand
        PictureBoxProjector.Image = CType(resources.GetObject("PictureBoxProjector.Image"), Image)
        PictureBoxProjector.Location = New Point(28, 280)
        PictureBoxProjector.Name = "PictureBoxProjector"
        PictureBoxProjector.Size = New Size(41, 36)
        PictureBoxProjector.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxProjector.TabIndex = 5
        PictureBoxProjector.TabStop = False
        ' 
        ' PictureBoxSoundSystem
        ' 
        PictureBoxSoundSystem.Cursor = Cursors.Hand
        PictureBoxSoundSystem.Image = CType(resources.GetObject("PictureBoxSoundSystem.Image"), Image)
        PictureBoxSoundSystem.Location = New Point(28, 226)
        PictureBoxSoundSystem.Name = "PictureBoxSoundSystem"
        PictureBoxSoundSystem.Size = New Size(41, 36)
        PictureBoxSoundSystem.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxSoundSystem.TabIndex = 4
        PictureBoxSoundSystem.TabStop = False
        ' 
        ' PictureBoxTent
        ' 
        PictureBoxTent.Cursor = Cursors.Hand
        PictureBoxTent.Image = CType(resources.GetObject("PictureBoxTent.Image"), Image)
        PictureBoxTent.Location = New Point(28, 174)
        PictureBoxTent.Name = "PictureBoxTent"
        PictureBoxTent.Size = New Size(41, 36)
        PictureBoxTent.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxTent.TabIndex = 3
        PictureBoxTent.TabStop = False
        ' 
        ' PictureBoxChair
        ' 
        PictureBoxChair.Cursor = Cursors.Hand
        PictureBoxChair.Image = CType(resources.GetObject("PictureBoxChair.Image"), Image)
        PictureBoxChair.Location = New Point(28, 120)
        PictureBoxChair.Name = "PictureBoxChair"
        PictureBoxChair.Size = New Size(41, 36)
        PictureBoxChair.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxChair.TabIndex = 2
        PictureBoxChair.TabStop = False
        ' 
        ' panelLeftSide
        ' 
        panelLeftSide.BackColor = Color.FromArgb(CByte(82), CByte(113), CByte(255))
        panelLeftSide.Location = New Point(18, 68)
        panelLeftSide.Name = "panelLeftSide"
        panelLeftSide.Size = New Size(10, 36)
        panelLeftSide.TabIndex = 1
        ' 
        ' PictureBoxTable
        ' 
        PictureBoxTable.Cursor = Cursors.Hand
        PictureBoxTable.Image = CType(resources.GetObject("PictureBoxTable.Image"), Image)
        PictureBoxTable.Location = New Point(28, 68)
        PictureBoxTable.Name = "PictureBoxTable"
        PictureBoxTable.Size = New Size(41, 36)
        PictureBoxTable.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBoxTable.TabIndex = 0
        PictureBoxTable.TabStop = False
        ' 
        ' Panel2
        ' 
        Panel2.BackColor = Color.FromArgb(CByte(82), CByte(113), CByte(255))
        Panel2.Dock = DockStyle.Top
        Panel2.Location = New Point(104, 0)
        Panel2.Name = "Panel2"
        Panel2.Size = New Size(731, 39)
        Panel2.TabIndex = 1
        ' 
        ' pnlTable
        ' 
        pnlTable.Controls.Add(lblAvailability)
        pnlTable.Controls.Add(btnSubmit)
        pnlTable.Controls.Add(Panel4)
        pnlTable.Controls.Add(Label1)
        pnlTable.Controls.Add(PictureBox1)
        pnlTable.Dock = DockStyle.Fill
        pnlTable.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        pnlTable.Location = New Point(104, 39)
        pnlTable.Name = "pnlTable"
        pnlTable.Size = New Size(731, 504)
        pnlTable.TabIndex = 2
        ' 
        ' lblAvailability
        ' 
        lblAvailability.AutoSize = True
        lblAvailability.Font = New Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        lblAvailability.Location = New Point(23, 29)
        lblAvailability.Name = "lblAvailability"
        lblAvailability.Size = New Size(102, 25)
        lblAvailability.TabIndex = 24
        lblAvailability.Text = "Available :"
        ' 
        ' btnSubmit
        ' 
        btnSubmit.FlatStyle = FlatStyle.Flat
        btnSubmit.Font = New Font("Segoe UI Black", 14.25F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        btnSubmit.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        btnSubmit.Location = New Point(400, 348)
        btnSubmit.Name = "btnSubmit"
        btnSubmit.Size = New Size(187, 36)
        btnSubmit.TabIndex = 23
        btnSubmit.Text = "Submit"
        btnSubmit.UseVisualStyleBackColor = True
        ' 
        ' Panel4
        ' 
        Panel4.BackColor = Color.FromArgb(CByte(82), CByte(113), CByte(255))
        Panel4.Controls.Add(DateTimePickerReturn)
        Panel4.Controls.Add(DateTimePickerBorrow)
        Panel4.Controls.Add(Label5)
        Panel4.Controls.Add(txtPurpose)
        Panel4.Controls.Add(PictureBox3)
        Panel4.Controls.Add(PictureBox2)
        Panel4.Controls.Add(TextBox1)
        Panel4.Controls.Add(Label7)
        Panel4.Controls.Add(Label4)
        Panel4.Controls.Add(Label2)
        Panel4.Controls.Add(Label3)
        Panel4.Controls.Add(txtName)
        Panel4.Location = New Point(275, 81)
        Panel4.Name = "Panel4"
        Panel4.Size = New Size(428, 326)
        Panel4.TabIndex = 2
        ' 
        ' DateTimePickerReturn
        ' 
        DateTimePickerReturn.Location = New Point(240, 124)
        DateTimePickerReturn.Name = "DateTimePickerReturn"
        DateTimePickerReturn.Size = New Size(138, 23)
        DateTimePickerReturn.TabIndex = 49
        ' 
        ' DateTimePickerBorrow
        ' 
        DateTimePickerBorrow.Location = New Point(240, 48)
        DateTimePickerBorrow.Name = "DateTimePickerBorrow"
        DateTimePickerBorrow.Size = New Size(138, 23)
        DateTimePickerBorrow.TabIndex = 48
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label5.Location = New Point(37, 162)
        Label5.Name = "Label5"
        Label5.Size = New Size(72, 21)
        Label5.TabIndex = 47
        Label5.Text = "Purpose"
        ' 
        ' txtPurpose
        ' 
        txtPurpose.BackColor = Color.White
        txtPurpose.BorderStyle = BorderStyle.None
        txtPurpose.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtPurpose.Location = New Point(37, 186)
        txtPurpose.Name = "txtPurpose"
        txtPurpose.Size = New Size(355, 36)
        txtPurpose.TabIndex = 46
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Cursor = Cursors.Hand
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(156, 124)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(21, 22)
        PictureBox3.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox3.TabIndex = 43
        PictureBox3.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Cursor = Cursors.Hand
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(42, 116)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(21, 22)
        PictureBox2.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox2.TabIndex = 42
        PictureBox2.TabStop = False
        ' 
        ' TextBox1
        ' 
        TextBox1.BackColor = Color.White
        TextBox1.BorderStyle = BorderStyle.None
        TextBox1.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(69, 110)
        TextBox1.Name = "TextBox1"
        TextBox1.ReadOnly = True
        TextBox1.Size = New Size(81, 36)
        TextBox1.TabIndex = 41
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label7.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label7.Location = New Point(37, 12)
        Label7.Name = "Label7"
        Label7.Size = New Size(56, 21)
        Label7.TabIndex = 40
        Label7.Text = "Name"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label4.Location = New Point(37, 86)
        Label4.Name = "Label4"
        Label4.Size = New Size(77, 21)
        Label4.TabIndex = 37
        Label4.Text = "Quantity"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label2.Location = New Point(240, 16)
        Label2.Name = "Label2"
        Label2.Size = New Size(105, 21)
        Label2.TabIndex = 36
        Label2.Text = "Borrow Date"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.FromArgb(CByte(70), CByte(196), CByte(255))
        Label3.Location = New Point(244, 91)
        Label3.Name = "Label3"
        Label3.Size = New Size(101, 21)
        Label3.TabIndex = 35
        Label3.Text = "Return Date"
        ' 
        ' txtName
        ' 
        txtName.BackColor = Color.White
        txtName.BorderStyle = BorderStyle.None
        txtName.Font = New Font("Segoe UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        txtName.Location = New Point(37, 36)
        txtName.Name = "txtName"
        txtName.Size = New Size(152, 36)
        txtName.TabIndex = 29
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(100, 352)
        Label1.Name = "Label1"
        Label1.Size = New Size(74, 32)
        Label1.TabIndex = 1
        Label1.Text = "Table"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Location = New Point(23, 81)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(246, 250)
        PictureBox1.TabIndex = 0
        PictureBox1.TabStop = False
        ' 
        ' Equipments
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(835, 543)
        Controls.Add(pnlTable)
        Controls.Add(Panel2)
        Controls.Add(Panel1)
        FormBorderStyle = FormBorderStyle.None
        Name = "Equipments"
        Text = "Equipments"
        Panel1.ResumeLayout(False)
        CType(PictureBoxLong, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxMic, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxScreen, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxProjector, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxSoundSystem, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxTent, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxChair, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBoxTable, ComponentModel.ISupportInitialize).EndInit()
        pnlTable.ResumeLayout(False)
        pnlTable.PerformLayout()
        Panel4.ResumeLayout(False)
        Panel4.PerformLayout()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents PictureBoxTable As PictureBox
    Friend WithEvents panelLeftSide As Panel
    Friend WithEvents PictureBoxChair As PictureBox
    Friend WithEvents PictureBoxLong As PictureBox
    Friend WithEvents PictureBoxMic As PictureBox
    Friend WithEvents PictureBoxScreen As PictureBox
    Friend WithEvents PictureBoxProjector As PictureBox
    Friend WithEvents PictureBoxSoundSystem As PictureBox
    Friend WithEvents PictureBoxTent As PictureBox
    Friend WithEvents pnlTable As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents txtPosition As TextBox
    Friend WithEvents txtClub As TextBox
    Friend WithEvents txtName As TextBox
    Friend WithEvents btnSubmit As Button
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents lblAvailability As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtPurpose As TextBox
    Friend WithEvents DateTimePickerReturn As DateTimePicker
    Friend WithEvents DateTimePickerBorrow As DateTimePicker
End Class
